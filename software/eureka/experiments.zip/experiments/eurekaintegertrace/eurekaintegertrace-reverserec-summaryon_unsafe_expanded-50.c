int a[50];
int y;

void swap(int d,int l) {
  a[d]=a[l];
  a[l] = a[d];
}

void reverse(int i, int k)
{
  if (i < k) {
    swap(i,k);
    skip
    reverse(i+1,k-1);
    skip
  } else {skip}
  skip
}

void main()
{
  int z;
  int x;

  z=0;
  while (z<50) {
    a[z]=undef;
    z=z+1;
  }
  z=0;
  while(z<10) {
    x=a[0];
    reverse(0,50-1);
    skip
    assert(a[50-1]==x);
    skip
    reverse(0,50-1);
    skip
    assert(a[0]==x);
    z=z+1;
  }
  skip
}
