int main() { 
  int i, n, sn,j;

  assume(n>=0 && n<1000);
  j=10;
  sn=0;
  i=1;

  while(i<=n) {
    sn = sn + 2;
    if (i<j) {sn = sn + 2;} else {skip}
    j=j-1;
    i=i+1;
  }
  skip
  assert(sn==n*2 || sn == 0);
  skip
}
