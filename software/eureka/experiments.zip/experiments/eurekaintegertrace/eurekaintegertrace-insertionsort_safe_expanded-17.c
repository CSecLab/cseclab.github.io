void main() {
  int a[17];
  int i,j,temp;
  
  i = 0;
  while(i<17) {
    a[i] = undef;
      i = i+1;
  }
  j = 1;
  while(j<17){
    temp = a[j];
    i = j-1;
    while(i>=0 && a[i]>temp){
      a[i+1] = a[i];
      i = i-1;
    }
    a[i+1]=temp;
    j=j+1;
  }
  assert(a[0]<=a[0+1] && a[1]<=a[1+1] && a[2]<=a[2+1] && a[3]<=a[3+1] && a[4]<=a[4+1] && a[5]<=a[5+1] && a[6]<=a[6+1] && a[7]<=a[7+1] && a[8]<=a[8+1] && a[9]<=a[9+1]);
assert(a[10]<=a[10+1] && a[11]<=a[11+1] && a[12]<=a[12+1] && a[13]<=a[13+1] && a[14]<=a[14+1] && a[15]<=a[15+1]);

 skip
}
