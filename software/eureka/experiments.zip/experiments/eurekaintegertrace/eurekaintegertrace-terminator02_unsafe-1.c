main()
{
  int x;
  int y;
  int z;
  int tmp;

  assume(x<100);
  skip
  assume(z<100);
  skip
  while(x<100 && 100<z) 
  {
    tmp=undef;
    if (tmp!=0)
      {
	x=x+1;
      }
    else
      {
	x=x-1;
	z=z-1;
      }
    skip
  }                       
  skip
  assert (x!=x);
  skip
}
