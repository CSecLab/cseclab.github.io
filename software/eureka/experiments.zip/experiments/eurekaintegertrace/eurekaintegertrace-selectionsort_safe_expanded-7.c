void main() {
  int a[7];
  int i,j,temp,min;

    i = 0;
    while(i<7) {
      a[i] = undef;
      i = i+1;
    }
    j = 0;
    while(j<7-1){
	min = j;
	temp = a[min];
	i = j+1;
	while(i<7){
	  if(a[i]<temp){
	    min = i;
	    temp = a[min];
	  } else { skip }
	  i = i+1;
	}
	temp = a[j]; 
	a[j] = a[min];	
	a[min] = temp;
	j=j+1;
    }
    assert(a[0]<=a[0+1] && a[1]<=a[1+1] && a[2]<=a[2+1] && a[3]<=a[3+1] && a[4]<=a[4+1] && a[5]<=a[5+1]);

 skip
}
