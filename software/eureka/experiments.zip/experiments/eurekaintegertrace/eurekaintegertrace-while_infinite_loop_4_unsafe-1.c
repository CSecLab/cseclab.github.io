int x;

void eval(void) 
{
  while (1==1) {
      x=1;
      goto l;
  }
 l:  return;
}


int main() {

  x=0;
  while(1==1)
  {
    eval();
    skip
    assert(x==0);    
  }
  assert(x==0);
  return 0;
}

