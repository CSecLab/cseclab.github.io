int s[93];
int p[2];

void main () {
  int i, j, l, found;

 i=0;
 while(i<93) {
   s[i]=undef;
   i=i+1;
 }
 skip
 i=0;
 while(i<2) {
   p[i]=undef;
   i=i+1;
 }
 skip

  i=0;
  found=0;
  while(i<93 && found==0) {
    j=0;
    l=i;
    while(j<2 && s[l]==p[j]) {
      assert(l>=0 && l<93);
      j=j+1;
      l=l+1;
      skip
    }
    skip
    if(j==2) {
      found=1;
    }
    skip
    i=i+1;
  }
  skip
  if (found==1)
    { assert(s[i]==p[1]); } else {skip}
  skip
}
