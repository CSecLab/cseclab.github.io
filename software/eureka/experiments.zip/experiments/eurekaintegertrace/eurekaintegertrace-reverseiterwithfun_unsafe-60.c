int a[60];

void reverse () {
  int i, k, tmp;
  i=0;
  while(i < 60) {
    k=60-1-i;
    tmp=a[k];
    a[k] = a[i];
    a[i]=tmp;
    i=i+1;
  } 
  skip
}

void main() {
  int x,j,tmp;

  x=0;
  while (x<5) {
    j=a[0];
    reverse();
    skip
    assert(j==a[60-1]);
    skip 
    reverse();
    assert(j==a[0]);
    x=x+1;
    }
skip
}
