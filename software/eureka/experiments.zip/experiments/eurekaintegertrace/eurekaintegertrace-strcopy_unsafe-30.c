void main() {
 int i,tmp;
 int a[30];
 int b[30];

 i=0;
 while(i<30) {
   a[i]=undef;
   b[i]=undef;
   i=i+1;
 }
 skip
 i = 0;
 while (b[i] != 0) {
    assert(i>=0 && i<30);
    tmp=b[i];
    a[i]=tmp;
    i = i + 1;
  }
  skip
}
