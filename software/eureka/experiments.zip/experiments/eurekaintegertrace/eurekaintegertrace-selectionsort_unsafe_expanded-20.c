void main() {
  int a[20];
  int i,j,temp,min;

    i = 0;
    while(i<20) {
      a[i] = undef;
      i = i+1;
    }
    j = 0;
    while(j<20-1){
	min = j;
	temp = a[min];
	i = j+1;
	while(i<20){
	  if(a[i]>temp){
	    min = i;
	    temp = a[min];
	  } else { skip }
	  i = i+1;
	}
	temp = a[j]; 
	a[j] = a[min];	
	a[min] = temp;
	j=j+1;
    }
 assert(a[0]<=a[0+1] && a[1]<=a[1+1] && a[2]<=a[2+1] && a[3]<=a[3+1] && a[4]<=a[4+1] && a[5]<=a[5+1] && a[6]<=a[6+1] && a[7]<=a[7+1] && a[8]<=a[8+1] && a[9]<=a[9+1]);
assert(a[10]<=a[10+1] && a[11]<=a[11+1] && a[12]<=a[12+1] && a[13]<=a[13+1] && a[14]<=a[14+1] && a[15]<=a[15+1] && a[16]<=a[16+1] && a[17]<=a[17+1] && a[18]<=a[18+1]);

 skip
}
