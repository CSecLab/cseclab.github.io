void main() {
  int a[2];
  int i,j,temp;
  
  i = 0;
  while(i<2) {
    a[i] = undef;
      i = i+1;
  }
  j = 1;
  while(j<2){
    temp = a[j];
    i = j-1;
    while(i>=0 && a[i]>temp){
      a[i+1] = a[i];
      i = i-1;
    }
    a[i+1]=temp;
    j=j+1;
  }
  assert(a[0]<=a[0+1]);

 skip
}
