int main() {
    char str1[5], str2[5];
    int i,j;


    str1[5-1] = 0;
    j=0;
    i=5-1;
    while (i >= 0) {
        str2[j] = str1[0];
        j=j+1;
	i=i-1;
    }
    i=0;
    j = 5-1;
    while (i<5) {
      assert(str1[i] == str2[j]);
      j=j-1;
      i=i+1;
    }
    skip
}
