void main() {
 int s1[10];
 int s2[10];
 int i,result;

 i=0;
 while (s1[i] == s2[i] && s1[i] != 0) {
  i=i+1;
  assert(i>=0 && i<10);
 }
 skip
 result = s1[i] - s2[i];
}
