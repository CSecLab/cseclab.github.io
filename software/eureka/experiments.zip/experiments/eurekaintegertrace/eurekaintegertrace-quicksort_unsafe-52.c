int a[52];
int q;

void swap(int g, int h)
{ int tmp;

  tmp=a[g];
  a[g] = a[h];
  a[h]=tmp;
}

void partition(int b, int c)
{
  int piv, i, j;

  i = b - 1;
  j = c + 1;
  piv = a[b];
  while (i < j){
    i=i+1;
    while (i<=c && a[i] <= piv){
      i=i+1;
    }
    j = j-1;
    while (j>=b && a[j] >= piv){
      j=j-1;
    }
    skip
    if (i < j) {
      swap(i,j);
      skip
    } 
    else {skip}
    skip
  }
  q=j;
  skip
}


void sort(int m, int n) 
{
  int o;

  o=0;
  while(o<52) {
    a[o]=undef;
    o=o+1;
  }
  o=0;
  if (m<n) {
    q=0;
    partition(m,n);
    skip
    o=q;
    q=0;
    assert(o<n);
    sort(m,o);
    skip
    q=0;
    sort(o+1,n);
    skip
    } else {skip}
  skip
}

void main()
{
  int s, t;
  s=0;
  t=52-1;
  
  sort(s,t);
  skip
}
