int a[38];
int q;

void swap(int g, int h)
{ int tmp;

  tmp=a[g];
  a[g] = a[h];
  a[h]=tmp;
}

void partition(int b, int c)
{
  int piv, i, j;

  i = b - 1;
  j = c + 1;
  piv = a[b];
  while (i < j){
    i=i+1;
    while (i<=c && a[i] <= piv){
      i=i+1;
    }
    j = j-1;
    while (j>=b && a[j] >= piv){
      j=j-1;
    }
    skip
    if (i < j) {
      swap(i,j);
      skip
    }
    else {skip}
    skip
  }
  q=j;
  skip
}

void main()
{

  int i;

  i=0;
  while(i<38) {
    a[i]=undef;
    i=i+1;
  }
  partition(0,38-1);
  skip
  assert(q<38-1);
  skip
}
