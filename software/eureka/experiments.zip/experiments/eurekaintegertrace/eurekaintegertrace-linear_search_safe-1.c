int a[30];
int out;

linearsearch(int n, int q) {
  int j;
 
  j=0;
  while (j<n && a[j]!=q) {
    j=j+1;
    //    if (j==10) { 
    //      j=-1;
    //    } else {skip}
    //    skip
  }
  skip
  if (j<n) {
    out = 1;
  } else {out= 0;}
  skip
}

main() { 
  int size;

  size=30;
  a[16]=4;
  linearsearch(size,4);
  skip
  assert(out==1);
  skip
}
