void main() {
 int i,tmp;
 int a[90];
 int b[90];

 i=0;
 while(i<90) {
   a[i]=undef;
   b[i]=undef;
   i=i+1;
 }
 skip
 i = 0;
 while (b[i] != 0) {
    assert(i>=0 && i<90);
    tmp=b[i];
    a[i]=tmp;
    i = i + 1;
  }
  skip
}
