int s[20];
int p[5];

void main () {
  int i, j, l, found;

 i=0;
 while(i<20) {
   s[i]=undef;
   i=i+1;
 }
 skip
 i=0;
 while(i<5) {
   p[i]=undef;
   i=i+1;
 }
 skip

  i=0;
  found=0;
  while(i<20 && found==0) {
    j=0;
    l=i;
    while(j<5 && s[l]==p[j]) {
      assert(l>=0 && l<20);
      j=j+1;
      l=l+1;
      skip
    }
    skip
    if(j==5) {
      found=1;
    }
    skip
    i=i+1;
  }
  skip
  if (found==1)
    { assert(s[i]==p[1]); } else {skip}
  skip
}
