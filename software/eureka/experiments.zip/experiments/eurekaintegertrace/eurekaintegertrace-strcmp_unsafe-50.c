void main() {
 int s1[50];
 int s2[50];
 int i,result;

 i=0;
 while (s1[i] == s2[i] && s1[i] != 0) {
  i=i+1;
  assert(i>=0 && i<50);
 }
 skip
 result = s1[i] - s2[i];
}
