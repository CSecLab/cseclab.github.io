void main() {
 int i,tmp;
 int a[70];
 int b[70];

 i=0;
 while(i<70) {
   a[i]=undef;
   b[i]=undef;
   i=i+1;
 }
 skip
 b[70-1]=0;
 i = 0;
 while (b[i] != 0) {
    assert(i>=0 && i<70);
    tmp=b[i];
    a[i]=tmp;
    i = i + 1;
  }
  skip
}
