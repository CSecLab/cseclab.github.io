int a[30];

void reverse () {
  int i, k, tmp;
  i=0;
  while(i < 15) {
    k=30-1-i;
    tmp=a[k];
    a[k] = a[i];
    a[i]=tmp;
    i=i+1;
  } 
  skip
}

void main() {
  int x,j,tmp;

  x=0;
  while (x<5) {
    j=a[0];
    reverse();
    skip
    assert(j==a[30-1]);
    skip 
    reverse();
    assert(j==a[0]);
    x=x+1;
    }
skip
}
