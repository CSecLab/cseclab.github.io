int a[50];

void main()
{
  int x,i,k,j,tmp;

  x=0;
  while (x<5) {
    j=a[0];
    i=0;
    while(i < 25) {
      k=50-1-i;
      tmp=a[k];
      a[k] = a[i];
      a[i]=tmp;
      i=i+1;
    } 
    skip
    assert(j==a[50-1]);
    skip 
    i=0;
    while(i < 50) {
      k=50-1-i;
      tmp=a[k];
      a[k] = a[i];
      a[i]=tmp;
      i=i+1;
    } 
    skip
   assert(j==a[0]);
    x=x+1;
    }
skip
}
