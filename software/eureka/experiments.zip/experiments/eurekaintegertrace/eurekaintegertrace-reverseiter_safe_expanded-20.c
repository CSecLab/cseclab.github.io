int a[20];

void main()
{
  int x,i,k,j,tmp;

  x=0;
  while (x<5) {
    j=a[0];
    i=0;
    while(i < 10) {
      k=20-1-i;
      tmp=a[k];
      a[k] = a[i];
      a[i]=tmp;
      i=i+1;
    } 
    skip
    assert(j==a[20-1]);
    skip 
    i=0;
    while(i < 10) {
      k=20-1-i;
      tmp=a[k];
      a[k] = a[i];
      a[i]=tmp;
      i=i+1;
    } 
    skip
   assert(j==a[0]);
    x=x+1;
    }
skip
}
