int main(){
   int a[5];
   int len;

   int i;

   len=0;
   while(undef){
     
     if (len==4) {
       len =0;} else {skip}
      
      a[len]=0;

      len=len+1;
   }
   skip
   assert(len>=0 && len<5);
   skip
}
