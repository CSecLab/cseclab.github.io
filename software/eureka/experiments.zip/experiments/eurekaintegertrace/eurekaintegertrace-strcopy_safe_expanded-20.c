void main() {
 int i,tmp;
 int a[20];
 int b[20];

 i=0;
 while(i<20) {
   a[i]=undef;
   b[i]=undef;
   i=i+1;
 }
 skip
 b[20-1]=0;
 i = 0;
 while (b[i] != 0) {
    assert(i>=0 && i<20);
    tmp=b[i];
    a[i]=tmp;
    i = i + 1;
  }
  skip
}
