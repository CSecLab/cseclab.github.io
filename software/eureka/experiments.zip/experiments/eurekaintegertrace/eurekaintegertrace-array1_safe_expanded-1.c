main()
{
  int j, menor;
  int array[1];

  menor = undef;
  j=0;
  while(j<1) {
    //       array[j] = undef;
       if(array[j]<=menor) {
           menor = array[j];
       } else {skip}
       j=j+1;
    }
   skip
    assert(array[0]>=menor);
   skip
}
