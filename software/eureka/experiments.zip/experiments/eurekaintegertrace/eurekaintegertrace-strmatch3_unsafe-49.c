int s[49];
int p[3];

void main () {
  int i, j, l, found;

 i=0;
 while(i<49) {
   s[i]=undef;
   i=i+1;
 }
 skip
 i=0;
 while(i<3) {
   p[i]=undef;
   i=i+1;
 }
 skip

  i=0;
  found=0;
  while(i<49 && found==0) {
    j=0;
    l=i;
    while(j<3 && s[l]==p[j]) {
      assert(l>=0 && l<49);
      j=j+1;
      l=l+1;
      skip
    }
    skip
    if(j==3) {
      found=1;
    }
    skip
    i=i+1;
  }
  skip
  if (found==1)
    { assert(s[i+1]==p[2]); } else {skip}
  skip
}
