int i,j;
int A[10];
int B[10];
int C[10];

int main()
{


  i=0;
  while(i<10) {
    A[i]=undef;
     i=i+1;
  }

  i=0;
  while(i<10) {
    B[i]=undef;
     i=i+1;
  }
  i=0;
  while(i<10) {
     C[i]=A[i]+B[i];
     i=i+1;
  }
  assume(j>=0 && j<10);
  skip
  assert(C[j]==A[j]-B[j]);
  skip
}
