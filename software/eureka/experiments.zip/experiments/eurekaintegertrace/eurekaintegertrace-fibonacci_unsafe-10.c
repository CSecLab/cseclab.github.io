int ans;

int fib(int n){
 int  i, Fnew, Fold, temp;

 Fnew = 1;  
 Fold = 1;
 i = 2;
 while( i <= n ) {
  temp = Fnew;
  Fnew = Fnew + Fold;
  Fold = temp;
  i=i+1;
 }
 ans = Fnew;
 skip
}
    
void main()
{
  int a;

  a = 10;
  fib(a);
  skip
  assert(ans==55);
  skip
}
