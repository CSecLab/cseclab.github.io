void main() {
 int i,tmp;
 int a[60];
 int b[60];

 i=0;
 while(i<60) {
   a[i]=undef;
   b[i]=undef;
   i=i+1;
 }
 skip
 b[60-1]=0;
 i = 0;
 while (b[i] != 0) {
    assert(i>=0 && i<60);
    tmp=b[i];
    a[i]=tmp;
    i = i + 1;
  }
  skip
}
