void main() {
 int i,tmp;
 int a[10];
 int b[10];

 i=0;
 while(i<10) {
   a[i]=undef;
   b[i]=undef;
   i=i+1;
 }
 skip
 i = 0;
 while (b[i] != 0) {
    assert(i>=0 && i<10);
    tmp=b[i];
    a[i]=tmp;
    i = i + 1;
  }
  skip
}
