int a[100];
int y;
int z;
int tmp;

void swap(int d,int l) 
{

  tmp=a[l];
  a[l] = a[d];
  a[d]=tmp;
}

void reverse(int i, int k)
{
  if (i < k) {
    swap(i,k);
    skip
    reverse(i+1,k-2);
    skip
  } else {skip}
  skip
}

void main()
{
  int x;

  z=0;
  while (z<100) {
    a[z]=undef;
    z=z+1;
  }
  z=0;
  while(z<10) {
    x=a[0];
    reverse(0,100-1);
    skip
    assert(a[100-1]==x);
    skip
    reverse(0,100-1);
    skip
    assert(a[0]==x);
    z=z+1;
  }
  skip
}
