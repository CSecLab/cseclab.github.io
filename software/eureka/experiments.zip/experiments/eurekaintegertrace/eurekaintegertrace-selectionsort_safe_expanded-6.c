void main() {
  int a[6];
  int i,j,temp,min;

    i = 0;
    while(i<6) {
      a[i] = undef;
      i = i+1;
    }
    j = 0;
    while(j<6-1){
	min = j;
	temp = a[min];
	i = j+1;
	while(i<6){
	  if(a[i]<temp){
	    min = i;
	    temp = a[min];
	  } else { skip }
	  i = i+1;
	}
	temp = a[j]; 
	a[j] = a[min];	
	a[min] = temp;
	j=j+1;
    }
    assert(a[0]<=a[0+1] && a[1]<=a[1+1] && a[2]<=a[2+1] && a[3]<=a[3+1] && a[4]<=a[4+1]);

 skip
}
