int x;

void foo() {
  x=x-1;
}

int main() {
  int c;
  
  x=undef;
  while (x > 0) {
    c = undef;
    if(c!=0) {foo(); skip} 
    else {foo(); skip}
    skip
  }
  skip
  assert(x==0);
  skip
}
