int x;
int y;

void swap() {
  int c;
  
  c = x;
  x = y;
  y = c;
}

void main(){
  int i;
  int z;

  x = 10;
  y = 20;
  z=x;
  swap();
  skip
  i=0;
  while (i<20) {
   swap();
   skip
   i=i+1;
  }
  while (i<20) {
   swap();
   skip
   i=i+1;
  }
  skip
  assert(z==y);
  skip 
}

